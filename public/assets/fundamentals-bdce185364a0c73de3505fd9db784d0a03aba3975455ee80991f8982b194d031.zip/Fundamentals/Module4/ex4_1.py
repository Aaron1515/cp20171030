# imports GPIO module and associated functions, and refer to it as "GPIO" throughout code
import RPi.GPIO as GPIO

# import time module and associated functions, and refer to it as "Time" throughout code
import time as Time



# sets pin numbering system for GPIO pin header 
GPIO.setmode(GPIO.BOARD)
# suppresses any warnings that may interrupt code
GPIO.setwarnings(False)
# sets pin 11 to input with pull-up resistor configuration (the input pin will read high state when not pressed)
GPIO.setup(11, GPIO.IN, GPIO.PUD_UP)
# sets pin 13 to output
GPIO.setup(13, GPIO.OUT)



# infintely repeating while loop
while True:
	# create variable button_state, which is set to True if pin 11 is pressed, and False if it is not pressed
	button_state = (GPIO.input(11)==0)

# Directions: Fill in the conditions for the "if" statement below, and fill in
# the codes for the LED lights such that the LED light is turned off in its
# default state, and when the button is pressed, the light will turn on.
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ BEGIN CODE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #

	if #[button is pressed#] :
		#Enter code to have LED light turn on here from GPIO Pin 13#
		print ("BUTTON PRESSED")
	else:
		#Enter code for default LED light state (off) from GPIO Pin 13#
		print ("CTRL+C To Stop Code!")
	Time.sleep(0.5)

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ END CODE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #


# sets all pins back to default 
GPIO.cleanup()