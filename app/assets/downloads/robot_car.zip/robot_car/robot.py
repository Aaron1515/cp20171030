#Import Raspberry Library of codes to our project
import RPi.GPIO as GPIO

#Import time to our project
import time as Time


# Note: The line of code below imports the functions you defined in the other
# python file, carfunctions.py, into this python file.

from carfunctions import Forward, Backward


# Exercise 1 Directions: Type in directional commands to your car below.
# Commands available are Forward and Backward for exercise 1.
# ~~~~~~~~~~~~~~~~~~~~ BEGIN CODE HERE ~~~~~~~~~~~~~~~~~~~~~ #





# ~~~~~~~~~~~~~~~~~~~~~~~ END CODE ~~~~~~~~~~~~~~~~~~~~~~~~~ #




# Exercise 2 Directions: Import the Left and Right functions from the
# carfunctions.py python file below, using the same command as above.
# Then type in directional commands to your car below. Commands 
# available are Forward, Backward, Left, and Right.
# ~~~~~~~~~~~~~~~~~~ BEGIN CODE HERE ~~~~~~~~~~~~~~~~~~~~~~ #





# ~~~~~~~~~~~~~~~~~~~~~~ END CODE ~~~~~~~~~~~~~~~~~~~~~~~~~ #


