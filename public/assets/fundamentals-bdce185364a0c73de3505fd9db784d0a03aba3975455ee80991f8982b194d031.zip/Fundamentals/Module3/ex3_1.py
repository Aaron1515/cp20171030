# imports GPIO module and associated functions, and refer to it as "GPIO" throughout code
import RPi.GPIO as GPIO

# import time module and associated functions, and refer to it as "Time" throughout code
import time as Time



# sets pin numbering system for GPIO pin header 
GPIO.setmode(GPIO.BOARD)
# sets pin 11 as an output (3.3V)
GPIO.setup(11, GPIO.OUT)
# suppresses any warnings that may interrupt code
GPIO.setwarnings(False)

# Directions: Use the comparison operator "==" to create a True statement for 
# the while loop.
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ BEGIN CODE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #

while #[Enter True Statement Here#] :


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ END CODE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #
	
	# sets pin 11 output to HIGH
	GPIO.output(11, GPIO.HIGH)
	# delays execution of next line of code for 0.5 seconds
	time.sleep(0.5)
	# sets pin 11 output to LOW
	GPIO.output(11, GPIO.LOW)
	# delays execution of next line of code for 0.5 seconds
	print("CTRL+C to stop this code") # repeatedly prints reminder to use CTRL+C to stop code
	Time.sleep(0.5)

# sets all pins back to default 
GPIO.cleanup()