#Import Raspberry Library of codes to our project
import RPi.GPIO as GPIO

#Import Time to our project
import time as Time

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)
GPIO.setup(11, GPIO.OUT)

# Directions: Use the comparison operator "==" to create a True statement for 
# the while loop.
# ~~~~~~~ BEGIN CODE ~~~~~~~ #

while #Enter True Statement Here# :


# ~~~~~~~~ END CODE ~~~~~~~ #
	
	GPIO.output(11, GPIO.HIGH)
	Time.sleep(0.5)
	GPIO.output(11, GPIO.LOW)
	Time.sleep(0.5)
	print("CTRL+C to stop this code")

GPIO.cleanup()