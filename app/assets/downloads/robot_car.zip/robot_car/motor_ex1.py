import RPi.GPIO as GPIO
import time as Time

GPIO.setmode(GPIO.BOARD)
GPIO.setup(11, GPIO.OUT)
GPIO.setup(13, GPIO.OUT)


# Directions: Refer to the truth table to set the appropriate output for the
# GPIO pins to rotate your wheel clockwise.
# --- ENTER CODE UNDER THIS LINE --- #

GPIO.output(11, True) 
GPIO.output(13, False)


# --- ENTER CODE ABOVE THIS LINE --- #

time.sleep(5)
GPIO.cleanup()
