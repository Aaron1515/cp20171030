#Import Raspberry Library of codes to our project
import RPi.GPIO as GPIO

#Import Time to our project
import time as Time

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)
GPIO.setup(11, GPIO.IN, GPIO.PUD_UP)
GPIO.setup(13, GPIO.OUT)

while True:
	button_state = (GPIO.input(11)==0)

# Directions: Fill in the conditions for the "if" and "then" statements below
# and the code such that when the button is held down, the LED 
# light will blink 3 Times.
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ BEGIN CODE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #

	if #button is pressed# :
		#Add for loop to make LED light blink 3 Times here#
		print ("BUTTON PRESSED")
	else:
		#Code for default state of LED light (off)#
		print ("Button is not pressed")
	Time.sleep(0.5)

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ END CODE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #


GPIO.cleanup()