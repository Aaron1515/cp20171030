import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)
GPIO.setup(11, gpio.OUT)
GPIO.setup(13, gpio.OUT)
GPIO.setup(15, gpio.OUT)
GPIO.setup(18, gpio.OUT)
GPIO.setup(19, gpio.OUT)
GPIO.setup(22, gpio.OUT)
GPIO.setup(12, gpio.OUT)
GPIO.setup(16, gpio.OUT)

GPIO.cleanup()
