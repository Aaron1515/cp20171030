#Import Raspberry Library of codes to our project
import RPi.GPIO as GPIO

#Import time to our project
import time as Time

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)

GPIO.setup(11, GPIO.IN, pull_up_down = GPIO.PUD_UP)
GPIO.setup(13, GPIO.IN, pull_up_down = GPIO.PUD_UP)
GPIO.setup(15, GPIO.OUT)
GPIO.setup(18, GPIO.OUT)

while True:
	button_state_1 = (GPIO.input(11)==0)
	button_state_2 = (GPIO.input(13)==0)


#Directions: Below is the code from the last exercise. Add on to the code with a new 
#if-else statement and using an "or" statement to turn your second LED light (connected
#to GPIO Pin 18) turn on if either button 1 or button 2 is pressed. Note that when both
#are pressed, both LED lights should turn on.

# ~~~~~~~~~~~~~~~~~~~~~~~~~ Type Code Here ~~~~~~~~~~~~~~~~~~~~~~~~~~~ #

	if button_state_1 == True and button_state_2 == True:
		GPIO.output(15, GPIO.HIGH)
		GPIO.output(18, GPIO.HIGH)
		
	else:
		GPIO.output(15, GPIO.LOW)
		GPIO.output(18, GPIO.LOW)


	#Add new if-else statement with "or" comparison#			

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~ End Code ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #
	Time.sleep(0.5)
	print("Ctrl + C to stop code!")
 
GPIO.cleanup()
