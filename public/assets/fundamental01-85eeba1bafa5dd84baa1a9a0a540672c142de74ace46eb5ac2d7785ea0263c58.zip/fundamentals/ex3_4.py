#Import Raspberry Library of codes to our project
import RPi.GPIO as GPIO

#Import Time to our project
import time as Time

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)
GPIO.setup(11, GPIO.OUT)


# Directions: Define variables using the "=" sign and use the "==" sign to
# make a comparison to form a True statement. Define the variable x as 2, 
# and a variable y as 1+1. Then compare the variables using "==" for the
# while loop. 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ BEGIN CODE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #

x = 
y = 




# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ END CODE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #

	GPIO.output(11, GPIO.HIGH)
	Time.sleep(0.5)
	GPIO.output(11, GPIO.LOW)
	Time.sleep(0.5)
	print("CTRL+C to stop this code")

GPIO.cleanup()
