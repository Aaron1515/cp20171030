# imports GPIO module and associated functions, and refer to it as "GPIO" throughout code
import RPi.GPIO as GPIO

# import time module and associated functions, and refer to it as "Time" throughout code
import time as Time



# sets pin numbering system for GPIO pin header 
GPIO.setmode(GPIO.BOARD)
# suppresses any warnings that may interrupt code
GPIO.setwarnings(False)


# sets pin 11 to input with pull-up resistor configuration (the input pin will read high state when not pressed)
GPIO.setup(11, GPIO.IN, pull_up_down = GPIO.PUD_UP)
# sets pin 13 to input with pull-up resistor configuration (the input pin will read high state when not pressed)
GPIO.setup(13, GPIO.IN, pull_up_down = GPIO.PUD_UP)
# sets pin 15 as an output (3.3V)
GPIO.setup(15, GPIO.OUT)
# sets pin 18 as an output (3.3V)
GPIO.setup(18, GPIO.OUT)


# Start an infinte while loop
while True:
	button_state_1 = (GPIO.input(11)==0) # create variable button_state_1, which is set to True if pin 11 is pressed, and False if it is not pressed
	button_state_2 = (GPIO.input(13)==0) # create variable button_state_2, which is set to True if pin 13 is pressed, and False if it is not pressed


#Directions: Below is the code from the last exercise. Add on to the code with a new 
#if-else statement and using an "or" statement to turn your second LED light (connected
#to GPIO Pin 18) turn on if either button 1 or button 2 is pressed. Note that when both
#are pressed, both LED lights should turn on.

# ~~~~~~~~~~~~~~~~~~~~~~~~~ Type Code Here ~~~~~~~~~~~~~~~~~~~~~~~~~~~ #

	if button_state_1 == True and button_state_2 == True:
		GPIO.output(15, GPIO.HIGH)
		GPIO.output(18, GPIO.HIGH)
		
	else:
		GPIO.output(15, GPIO.LOW)
		GPIO.output(18, GPIO.LOW)
		

	#Add new if-else statement with "or" comparison#			

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~ End Code ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #

	# delays execution of next line of code for 0.5 second
	Time.sleep(0.5)
	# repeatedly prints reminder to press CTRL+C to stop looping code
	print "CTRL + C to Stop Code!"
 
# sets all pins back to default 
GPIO.cleanup()