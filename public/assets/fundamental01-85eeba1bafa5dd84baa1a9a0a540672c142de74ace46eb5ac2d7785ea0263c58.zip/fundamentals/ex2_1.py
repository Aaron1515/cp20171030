#Import Raspberry Library of codes to our project
import RPi.GPIO as GPIO

#Import time to our project
import time as Time

GPIO.setmode(GPIO.BOARD)
GPIO.setup(11, GPIO.OUT)
GPIO.setwarnings(False)

#Directions: Create a For loop that will turn your LED light on for one second
#and turn your LED light off for one second and have this repeat five times.
#Use the syntax from the pre-lesson and the time.sleep(1) function.
# ~~~~~~~~~~~~~~~~~~~~~~~~~ Type Code Here ~~~~~~~~~~~~~~~~~~~~~~~~~~~#




# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~ End Code ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
 
GPIO.cleanup()