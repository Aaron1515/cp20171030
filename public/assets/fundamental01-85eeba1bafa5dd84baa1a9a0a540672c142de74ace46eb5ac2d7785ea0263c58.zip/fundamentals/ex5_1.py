#Import Raspberry Library of codes to our project
import RPi.GPIO as GPIO

#Import time to our project
import time as Time

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)

GPIO.setup(11, GPIO.IN, pull_up_down = GPIO.PUD_UP)
GPIO.setup(13, GPIO.IN, pull_up_down = GPIO.PUD_UP)
GPIO.setup(15, GPIO.OUT)
GPIO.setup(18, GPIO.OUT)

while True:
	button_state_1 = (GPIO.input(11)==0)
	button_state_2 = (GPIO.input(13)==0)


#Directions: Use "and" to compare button_state_1 and button_state_2 as true statements. 
#Write code such that when both are pressed at the same Time, both lights will turn on
#and when you only press one button, neither light should turn on. When neither button
#is pressed, the lights should also remain off.
# ~~~~~~~~~~~~~~~~~~~~~~~~~ Type Code Here ~~~~~~~~~~~~~~~~~~~~~~~~~~~#

	if #Enter Condition Using "and" comparison here# :

	else:	


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~ End Code ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
	Time.sleep(0.5)
	print "CTRL + C to Stop Code!"  
 
GPIO.cleanup()
