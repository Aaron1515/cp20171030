# imports GPIO module and associated functions, and refer to it as "GPIO" throughout code
import RPi.GPIO as GPIO

# import time module and associated functions, and refer to it as "Time" throughout code
import time as Time



# sets pin numbering system for GPIO pin header 
GPIO.setmode(GPIO.BOARD)
# suppresses any warnings that may interrupt code
GPIO.setwarnings(False)
# sets pin 11 to input with pull-up resistor configuration (the input pin will read high state when not pressed)
GPIO.setup(11, GPIO.IN, GPIO.PUD_UP)
# sets pin 13 to output
GPIO.setup(13, GPIO.OUT)


# Start an infintely while loop
while True:
	button_state = (GPIO.input(11)==0) # create variable button_state, which is set to True if pin 11 is pressed, and False if it is not pressed

# Directions: Fill in the conditions for the "if" and "then" statements below
# and the code such that when the button is held down, the LED 
# light will blink 3 times.
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ BEGIN CODE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #

	if #[button is pressed] :
		#Add for loop to make LED light blink 3 times here#
		print ("BUTTON PRESSED")
	else:
		#Code for default state of LED light (off)#
		print ("Button is not pressed")
	Time.sleep(0.5)

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ END CODE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #


# sets all pins back to default 
GPIO.cleanup()