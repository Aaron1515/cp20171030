# imports GPIO module and associated functions, and refer to it as "GPIO" throughout code
import RPi.GPIO as GPIO

# import time module and associated functions, and refer to it as "Time" throughout code
import time as Time


# sets pin numbering system for GPIO pin header 
GPIO.setmode(GPIO.BOARD)
# sets pin 11 as an output (3.3V)
GPIO.setup(11, GPIO.OUT)
# suppresses any warnings that may interrupt code
GPIO.setwarnings(False)

# Directions: Set GPIO Pin 11 to HIGH to turn on your LED light.
# ~~~~~~~~~~~~~~~~~~~~~ Type Code Here ~~~~~~~~~~~~~~~~~~~~ #





# ~~~~~~~~~~~~~~~~~~~~~~~~ End Code ~~~~~~~~~~~~~~~~~~~~~~~ #

# delays execution of next line of code for 5 seconds
Time.sleep(5)

# sets all pins back to default 
GPIO.cleanup()
