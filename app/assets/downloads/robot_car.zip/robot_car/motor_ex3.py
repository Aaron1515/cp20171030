import RPi.GPIO as GPIO
import time as Time

GPIO.setmode(GPIO.BOARD)
GPIO.setup(11, GPIO.OUT)
GPIO.setup(13, GPIO.OUT)


# Directions: Refer to the truth table to set the appropriate output for the
# GPIO pins to rotate your wheel clockwise for five seconds, and then 
# counter-clockwise for 5 seconds. Remember to use the Time.sleep() function.
# --- ENTER CODE HERE --- #

GPIO.output(11, True)
GPIO.output(13, False)
Time.sleep(5)
GPIO.output(11, False)
GPIO.output(13, True)

# --- END CODE --- #

Time.sleep(5)
GPIO.cleanup()