#Import Raspberry Library of codes to our project
import RPi.GPIO as GPIO

#Import time to our project
import time as Time

GPIO.setmode(GPIO.BOARD)
GPIO.setup(11, GPIO.OUT)
GPIO.setwarnings(False)

# Directions: Set GPIO Pin 11 to HIGH to turn on your LED light.
# ~~~~~~~~ Type Code Here ~~~~~~~~~ #





# ~~~~~~~~~~~~ End Code ~~~~~~ #

Time.sleep(5)
GPIO.cleanup()
