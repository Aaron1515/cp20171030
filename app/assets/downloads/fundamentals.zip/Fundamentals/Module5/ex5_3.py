# imports GPIO module and associated functions, and refer to it as "GPIO" throughout code
import RPi.GPIO as GPIO

# import time module and associated functions, and refer to it as "Time" throughout code
import time as Time



# sets pin numbering system for GPIO pin header 
GPIO.setmode(GPIO.BOARD)
# suppresses any warnings that may interrupt code
GPIO.setwarnings(False)

# sets pin 11 to input with pull-up resistor configuration (the input pin will read high state when not pressed)
GPIO.setup(11, GPIO.IN, pull_up_down = GPIO.PUD_UP)
# sets pin 13 to input with pull-up resistor configuration (the input pin will read high state when not pressed)
GPIO.setup(13, GPIO.IN, pull_up_down = GPIO.PUD_UP)
# sets pin 15 as an output (3.3V)
GPIO.setup(15, GPIO.OUT)
# sets pin 18 as an output (3.3V)
GPIO.setup(18, GPIO.OUT)

# Start an infinte while loop
while True:
	# create variable button_state_1, which is set to True if pin 11 is pressed, and False if it is not pressed
	button_state_1 = (GPIO.input(11)==0)
	# create variable button_state_2, which is set to True if pin 13 is pressed, and False if it is not pressed
	button_state_2 = (GPIO.input(13)==0)



#Directions: Set up your if/else statements. Use the "is not" comparison statement, !=,
#to create a condition where both LED lights remain on if both buttons are not pressed.
#If either button or both buttons are pressed, both LED lights will turn off. Note the 
#default state of the lights should be on.

# ~~~~~~~~~~~~~~~~~~~~~~~~~ Type Code Here ~~~~~~~~~~~~~~~~~~~~~~~~~~~ #





# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~ End Code ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #
	# delays execution of next line of code for 0.1 second
	Time.sleep(0.1)
	# repeatedly prints reminder to press CTRL+C to stop looping code
	print "CTRL + C to Stop Code!"
 
# sets all pins back to default 
GPIO.cleanup()