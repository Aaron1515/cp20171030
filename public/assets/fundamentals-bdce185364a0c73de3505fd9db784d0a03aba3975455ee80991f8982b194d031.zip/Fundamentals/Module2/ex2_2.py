# imports GPIO module and associated functions, and refer to it as "GPIO" throughout code
import RPi.GPIO as GPIO

# import time module and associated functions, and refer to it as "Time" throughout code
import time as Time


# sets pin numbering system for GPIO pin header 
GPIO.setmode(GPIO.BOARD)
# sets pin 11 as an output (3.3V)
GPIO.setup(13, GPIO.OUT)
# sets pin 13 as an output (3.3V)
GPIO.setup(11, GPIO.OUT)
# suppresses any warnings that may interrupt code
GPIO.setwarnings(False)

#Directions: Create two different 'for loops' that will cause two individual
#LED lights to blink at different rates. Make sure that the light only
#blinks five times!

# ~~~~~~~~~~~~~~~~~~~~~~~~~ Type Code Here ~~~~~~~~~~~~~~~~~~~~~~~~~~~#





# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~ End Code ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
 
# sets all pins back to default 
GPIO.cleanup()