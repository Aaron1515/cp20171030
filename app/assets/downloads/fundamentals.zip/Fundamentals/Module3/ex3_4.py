# imports GPIO module and associated functions, and refer to it as "GPIO" throughout code
import RPi.GPIO as GPIO

# import time module and associated functions, and refer to it as "Time" throughout code
import time as Time



# sets pin numbering system for GPIO pin header 
GPIO.setmode(GPIO.BOARD)
# sets pin 11 as an output (3.3V)
GPIO.setup(11, GPIO.OUT)
# suppresses any warnings that may interrupt code
GPIO.setwarnings(False)


# Directions: Define variables using the "=" sign and use the "==" sign to
# make a comparison to form a True statement. Define the variable x as 2, 
# and a variable y as 1+1. Then compare the variables using "==" for the
# while loop. 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ BEGIN CODE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #

x = 
y =  




# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ END CODE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #
	
	# sets pin 11 output to HIGH
	GPIO.output(11, GPIO.HIGH)
	# delays execution of next line of code for 0.5 seconds
	time.sleep(0.5)
	# sets pin 11 output to LOW
	GPIO.output(11, GPIO.LOW)
	# delays execution of next line of code for 0.5 seconds
	time.sleep(0.5)
	# repeatedly prints reminder to use CTRL+C to stop code
	print("CTRL+C to stop this code")

# sets all pins back to default 
GPIO.cleanup()