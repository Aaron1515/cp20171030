#Import Raspberry Library of codes to our project
import RPi.GPIO as GPIO

#Import Time to our project
import time as Time

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)
GPIO.setup(11, GPIO.IN, GPIO.PUD_UP)
GPIO.setup(13, GPIO.OUT)

while True:
	button_state = (GPIO.input(11)==0)

# Directions: Fill in the conditions for the "if" statement below
# and the conditional code such that the light's default state is on, and 
# when the button is pressed, the LED light will turn off.
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ BEGIN CODE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #

	if #button is pressed# #Remember to add colon!#
		#Enter in code to turn off LED light#
		print ("BUTTON PRESSED")
	else:
		#Enter in code for LED light's default state (on)#
		print ("CTRL+C To Exit Code!")
	Time.sleep(0.5)

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ END CODE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #


GPIO.cleanup()
