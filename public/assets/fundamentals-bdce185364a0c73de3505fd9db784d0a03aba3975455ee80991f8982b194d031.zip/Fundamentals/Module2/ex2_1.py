# imports GPIO module and associated functions, and refer to it as "GPIO" throughout code
import RPi.GPIO as GPIO

# import time module and associated functions, and refer to it as "Time" throughout code
import time as Time



# sets pin numbering system for GPIO pin header 
GPIO.setup(11, GPIO.OUT)
# sets pin 11 as an output (3.3V)
GPIO.setwarnings(False)
# suppresses any warnings that may interrupt code
GPIO.setmode(GPIO.BOARD)

#Directions: Create a For loop that will turn your LED light on for one second
#and turn your LED light off for one second and have this repeat five times.
#Use the syntax from the Module 2 lesson and the time.sleep(1) function.
# ~~~~~~~~~~~~~~~~~~~~~~~~~ Type Code Here ~~~~~~~~~~~~~~~~~~~~~~~~~~~#



	

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~ End Code ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
 
# sets all pins back to default 
GPIO.cleanup()
