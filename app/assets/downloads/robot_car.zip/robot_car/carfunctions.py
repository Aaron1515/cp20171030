import RPi.GPIO as GPIO
import time as Time


def setup():
	GPIO.setmode(GPIO.BOARD)
	GPIO.setup(11, GPIO.OUT)
	GPIO.setup(13, GPIO.OUT)
	GPIO.setup(15, GPIO.OUT)
	GPIO.setup(18, GPIO.OUT)


# EXERCISE 1 #

# Directions: Below, the syntax for defining the function Forward is given. Set the
# appriopriate GPIO pin outputs to move the car forward according to the truth table.
# The variable "num" is the number of seconds that your car will travel in the
# defined direction (HINT: Use Time.sleep). Then, define the function Backward 
# below the Forward function.

# --- ENTER CODE UNDER HERE --- #


def Forward(num):

	setup()

	print 'Forward'

	GPIO.output(11, False)
	GPIO.output(13, True)
	GPIO.output(15, False)
	GPIO.output(18, True)
	Time.sleep(num)
	GPIO.cleanup()
	return;


def Backward(num):

	setup()

	print 'Backward'

	# Enter code here #

	return;

# --- ENTER CODE ABOVE THIS --- #



		
# EXERCISE 2 #

# Directions: See your defined functions from exercise 1 above to define the Left 
# and Right functions below. Set the appriopriate GPIO pin outputs to move the car
# left and right  according to the truth table. Remember to incorporate the variable 
# "num", which is the number of seconds that your car will travel in the
# defined direction (HINT: Use Time.sleep).
# --- ENTER CODE HERE --- #








# --- END CODE --- #

