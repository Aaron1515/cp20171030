#Import Raspberry Library of codes to our project
import RPi.GPIO as GPIO

#Import time to our project
import time as Time

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False) 

GPIO.setup(11, GPIO.IN, pull_up_down = GPIO.PUD_UP)
GPIO.setup(13, GPIO.IN, pull_up_down = GPIO.PUD_UP)
GPIO.setup(15, GPIO.OUT)
GPIO.setup(18, GPIO.OUT)

while True:
	button_state_1 = (GPIO.input(11)==0)
	button_state_2 = (GPIO.input(13)==0)


#Directions: Set up your if/else statements. Use the "is not" comparison statement, !=,
#to create a condition where both LED lights remain on if both buttons are not pressed.
#If either button or both buttons are pressed, both LED lights will turn off. Note the 
#default state of the lights should be on.

# ~~~~~~~~~~~~~~~~~~~~~~~~~ Type Code Here ~~~~~~~~~~~~~~~~~~~~~~~~~~~ #





# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~ End Code ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #
	Time.sleep(0.1)
	print("Ctrl + C to stop code!")
 
GPIO.cleanup()
