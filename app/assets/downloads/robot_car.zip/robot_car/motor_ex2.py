import RPi.GPIO as GPIO
import time as Time

GPIO.setmode(GPIO.BOARD)
GPIO.setup(11, GPIO.OUT)
GPIO.setup(13, GPIO.OUT)


# Directions: Refer to the truth table to set the appropriate output for the
# GPIO pins to rotate your wheel counter-clockwise.
# --------------------------- ENTER CODE HERE ---------------------------- #

GPIO.output(11, False)
GPIO.output(13, True)



# ----------------------------- END CODE --------------------------------- #

Time.sleep(5)
GPIO.cleanup()
